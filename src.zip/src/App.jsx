import React from "react";
import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import ShopList from "./components/ShopList";

const App = () => {
  return (
    <>
      <Navbar />
         <div className="main_content">
           <ShopList />
         </div>
      <Footer />
    </>
  );
};

export default App;

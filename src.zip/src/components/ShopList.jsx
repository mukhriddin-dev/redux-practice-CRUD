import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { FetchData, FetchListUpdate, FetchError } from "../actions/action";
import Spinner from "./Spinner";
import Error from "./Error";

const ShopList = () => {
  const { Shop, loading, ShopFilter } = useSelector((state) => state);

  const dispatch = useDispatch();


  useEffect(() => {
    dispatch(FetchData()),
      axios
        .get("http://localhost:5000/shop")
        .then((data) => dispatch(FetchListUpdate(data.data)))
        .catch(() => dispatch(FetchError()));
  }, []);

  
  const deletInfo=()=>{
      axios.delete("http://localhost:5000/shop/1",{})
  }


  


  


if(loading==="error"){
  return <Error/>
}

  if (loading === "false") {
    return (
      <>
        { Shop.length ?  Shop.map((item) => (

          <div className="card">
            <span>{item.id}</span>
            <span>{item.name}</span>
            <span>{item.addres}</span>

            <button onClick={deletInfo} className="btn btn-danger m-3">DELET</button>

          </div>

        ) ) : <h2 className="card mx-auto bg-info p-5 m-5"> Ma'lumot yo'q </h2> }

      </>
    );
  }else {
    return <Spinner />;
  }



  return (
    <div className="card p-3 m-2">
      <></>
    </div>
  );
};

export default ShopList;

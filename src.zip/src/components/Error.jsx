import React from "react";

const Error = () => {
  return (
    <div className="card bg-danger mx-auto w-50 p-5 m-5">
      <h3>404 NOT FOUND</h3>
    </div>
  );
};

export default Error;

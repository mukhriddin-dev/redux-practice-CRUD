import React from "react";

const Navbar = () => {
  return (
    <>
      <nav className="navbar navbar-light bg-success">
        <div className="container-fluid">
          <a className="navbar-brand text-white" href="#">
            TRAVEL WEB-SITE
          </a>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
